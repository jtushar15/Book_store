﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class welcome : Form
    {
        public welcome()
        {
            InitializeComponent();
        }

        private void welcome_Load(object sender, EventArgs e)
        {

        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void adminbtn_Click(object sender, EventArgs e)
        {
            adminlogin log = new adminlogin();
            log.Show();

        }

        private void userbtn_Click(object sender, EventArgs e)
        {
            userlogin use = new userlogin();
            use.Show();

            userlogin nextfom = new userlogin();
            this.Hide();
            nextfom.ShowDialog();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

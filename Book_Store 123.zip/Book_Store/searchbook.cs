﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class searchbook : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        public searchbook()
        {
            InitializeComponent();
        }

        private void cmbsearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbsearch.Text != "")
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select * from tblBookdtl where Category='" + cmbsearch.Text + "'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds, "fff");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "fff";

                }
            }
        }
        private void searchbook_load(object sender, EventArgs e)
        {
            userlogin userlogin = new userlogin();
            userlogin.Hide();
            userlogin.Close();
        }

        private void searchbook_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbBookStoreDataSet3.tblBookdtl' table. You can move, or remove it, as needed.
            this.tblBookdtlTableAdapter.Fill(this.dbBookStoreDataSet3.tblBookdtl);
            // TODO: This line of code loads data into the 'dbBookStoreDataSet2.tblBookdtl' table. You can move, or remove it, as needed.
          //  this.tblBookdtlTableAdapter.Fill(this.dbBookStoreDataSet2.tblBookdtl);
            // TODO: This line of code loads data into the 'dbBookStoreDataSet1.tblBookdtl' table. You can move, or remove it, as needed.
            //  this.tblBookdtlTableAdapter.Fill(this.dbBookStoreDataSet1.tblBookdtl);
            // TODO: This line of code loads data into the 'dbBookStoreDataSet.tblBookdtl' table. You can move, or remove it, as needed.

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from tblBookdtl", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds, "fff");
            if (ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "fff";
            }
        }

        private void caToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void comicToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void classicToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == 0 && e.ColumnIndex == 0)
            {

                string url = "https://pisaucer.github.io/book-c-plus-plus/Beginning_Cpp_Through_Game_Programming.pdf";
                string savePath = @"D:\Book_Store\book\C++ Programming.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("C++ Programming Book Download Sucessfully");
            }
            else if(e.RowIndex == 1 && e.ColumnIndex == 0)
            {
                string url = "https://pd.daffodilvarsity.edu.bd/course/material/book-430/pdf_content";
                string savePath = @"D:\Book_Store\book\Data Structure.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("Data Struture Book Download Sucessfully");
            }
            else if (e.RowIndex == 2 && e.ColumnIndex == 0)
            {
                string url = "D://ALL BCS NOTES//6th semister all notes//Android//Android notes for professionals .pdf/";
                string savePath = @"D:\Book_Store\book\android.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("Data Struture Book Download Sucessfully");
            }
            else if (e.RowIndex == 2 && e.ColumnIndex == 0)
            {
                string url = "D://notes//DBMS Unit 1.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("DBMS Book Download Sucessfully");
            }
            else if (e.RowIndex == 3 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/parshuram_sandeep_surve.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show(" parshuram_sandeep_surveSucessfully");
            }
            else if (e.RowIndex == 4 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/chandrayaan_ankush_shingade.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("chandrayaan_ankush_shingade");
            }
            else if (e.RowIndex == 5 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/teeee_milind_kapale-1.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("teeee_milind_kapale-1");
            }
            else if (e.RowIndex == 6 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/phule-mar.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("phule-mar");
            }
            else if (e.RowIndex == 7 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/mar-nbt-jnehru.pdf";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("mar-nbt-jnehru");
            }
            else if (e.RowIndex == 7 && e.ColumnIndex == 0)
            {
                string url = "file:///C:/Users/hp/OneDrive/Desktop/FRY%20-MARATHI.pdff";
                string savePath = @"D:\Book_Store\book\DBMS.pdf";
                WebClient client = new WebClient();
                client.DownloadFile(url, savePath);
                Console.ReadLine();
                MessageBox.Show("FRY%20-MARATHI");
            }


            else
            {
                MessageBox.Show("No book available to download");
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            


        }
    }
}

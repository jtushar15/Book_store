﻿namespace Book_Store
{
    partial class searchbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbsearch = new System.Windows.Forms.ComboBox();
            this.tblBookdtlBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbBookStoreDataSet3 = new Book_Store.dbBookStoreDataSet3();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Download = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tblBookdtlTableAdapter = new Book_Store.dbBookStoreDataSet3TableAdapters.tblBookdtlTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.tblBookdtlBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBookStoreDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Gold;
            this.button2.Location = new System.Drawing.Point(839, 1);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(157, 39);
            this.button2.TabIndex = 11;
            this.button2.Text = "CLOSE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gold;
            this.button1.Location = new System.Drawing.Point(621, 1);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 39);
            this.button1.TabIndex = 10;
            this.button1.Text = "SHOW ALL";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbsearch
            // 
            this.cmbsearch.DataSource = this.tblBookdtlBindingSource;
            this.cmbsearch.DisplayMember = "Category";
            this.cmbsearch.FormattingEnabled = true;
            this.cmbsearch.Location = new System.Drawing.Point(277, 13);
            this.cmbsearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbsearch.Name = "cmbsearch";
            this.cmbsearch.Size = new System.Drawing.Size(333, 24);
            this.cmbsearch.TabIndex = 7;
            this.cmbsearch.ValueMember = "bookid";
            this.cmbsearch.SelectedIndexChanged += new System.EventHandler(this.cmbsearch_SelectedIndexChanged);
            // 
            // tblBookdtlBindingSource
            // 
            this.tblBookdtlBindingSource.DataMember = "tblBookdtl";
            this.tblBookdtlBindingSource.DataSource = this.dbBookStoreDataSet3;
            // 
            // dbBookStoreDataSet3
            // 
            this.dbBookStoreDataSet3.DataSetName = "dbBookStoreDataSet3";
            this.dbBookStoreDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Download});
            this.dataGridView1.Location = new System.Drawing.Point(13, 55);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(983, 479);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Download
            // 
            this.Download.HeaderText = "Download";
            this.Download.MinimumWidth = 6;
            this.Download.Name = "Download";
            this.Download.Text = "C Programming";
            this.Download.Width = 125;
            // 
            // tblBookdtlTableAdapter
            // 
            this.tblBookdtlTableAdapter.ClearBeforeFill = true;
            // 
            // searchbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 551);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbsearch);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "searchbook";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "searchbook";
            this.Load += new System.EventHandler(this.searchbook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblBookdtlBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbBookStoreDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbsearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private dbBookStoreDataSet3 dbBookStoreDataSet3;
        private System.Windows.Forms.BindingSource tblBookdtlBindingSource;
        private dbBookStoreDataSet3TableAdapters.tblBookdtlTableAdapter tblBookdtlTableAdapter;
        private System.Windows.Forms.DataGridViewButtonColumn Download;
    }
}
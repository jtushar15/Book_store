﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class signuppage : Form
    {
        public signuppage()
        {
            InitializeComponent();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void brnsignup_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string pass = textBox2.Text;
            string cnfirmpass = textBox3.Text;
            string email = textBox4.Text;
            string Mobno = textBox5.Text;
            if (user == "" | pass == "" |  cnfirmpass == "" | email == "" | Mobno == "")
            {
                MessageBox.Show("Kindly Confirm Password");
                return;
            }
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            string insertQuery = "insert into tblSignUp(username,password,confirm_password,email_id,Mobno) VALUES (@a,@b,@c,@d,@e)";
            SqlCommand insertcmd = new SqlCommand(insertQuery, con);
            insertcmd.Parameters.AddWithValue("@a", user);
            insertcmd.Parameters.AddWithValue("@b", pass);
            insertcmd.Parameters.AddWithValue("@c", cnfirmpass);
            insertcmd.Parameters.AddWithValue("@d", email);
            insertcmd.Parameters.AddWithValue("@e", Mobno);

            con.Open();
            if (pass == cnfirmpass) 
            {
              insertcmd.ExecuteNonQuery();
                MessageBox.Show("User Added Sucessfuly...!");
                using (userlogin b = new userlogin()) 
                {
                  b.ShowDialog();
                }
            }

            con.Close();
            user = "";
            pass = "";
            cnfirmpass = "";
            email = "";
            this.Close();
            signuppage nextform = new signuppage(); 
            this.Hide();
            nextform.ShowDialog();
            

        }
    }
}

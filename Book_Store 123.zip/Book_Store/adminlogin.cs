﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class adminlogin : Form
    {
        public adminlogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string pass = textBox2.Text;
            if (name == "" | pass == "")
            {
                MessageBox.Show("Plz fill the data fields");
                return;
            }
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            string selectQuery = "select username, password from tbladminlog WHERE username=@id AND password=@pass";
            SqlCommand cmd = new SqlCommand(selectQuery, con);
            cmd.Parameters.AddWithValue("@id", name);
            cmd.Parameters.AddWithValue("@pass", pass);
            con.Open();


            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();

                MessageBox.Show(" Login Succesfully!");
                Admin_Home obj = new Admin_Home();
                obj.Show();

            }
            else
            {
                MessageBox.Show("User not found !");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void adminlogin_Load(object sender, EventArgs e)
        {

        }
    }
}


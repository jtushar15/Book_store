﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class Admin_Home : Form
    {
        public Admin_Home()
        {
            InitializeComponent();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddBookbtn_Click(object sender, EventArgs e)
        {
            using (Add_Book_Dtl c = new Add_Book_Dtl())
            {
                c.ShowDialog();
            }
        }

        private void editbtn_Click(object sender, EventArgs e)
        {
            using (updatebook c = new updatebook()) 
            {
              c.ShowDialog();
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            /*using (viewbook c = new viewbook()) 
            {
                c.ShowDialog();

            }*/
            viewbook viewbook = new viewbook();
            viewbook.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (viewbook c = new viewbook())
            { 
                c.ShowDialog();
            }
        }

        private void Admin_Home_Load(object sender, EventArgs e)
        {

        }
    }
}

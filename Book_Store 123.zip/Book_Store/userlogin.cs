﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class userlogin : Form
    {
        public userlogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            signuppage obj = new signuppage();
            obj.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                
        }

        private void userlogin_Load(object sender, EventArgs e)
        {
            //welcome obj = new welcome();
           // obj.Show();
        }

      

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlDataAdapter adp = new SqlDataAdapter("select * from tblSignUp where username='" + textBox1.Text + "'", con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {

                searchbook frm = new searchbook();
                if (textBox1.Text == ds.Tables[0].Rows[0]["username"].ToString() && textBox2.Text == ds.Tables[0].Rows[0]["password"].ToString())
                {
                    if (textBox1.Text != "Admin")
                    {

                       //this.Hide();
                        frm.Show();
                       // this.Hide();
                       userlogin t = new userlogin();
                        t.Hide();
                        t.Close();
                    }
                    else
                    {
                        frm.Show();
                        this.Hide();
                        
                    }
                }
                else
                {
                    MessageBox.Show("Password Incorrect");
                    textBox2.Clear();
                }
            }
            else
            {
                MessageBox.Show("UserName or Password Incorrect", "Error in Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Clear();
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            forget cs = new forget();
            this.Hide();
            cs.Show();
        }
    }
}

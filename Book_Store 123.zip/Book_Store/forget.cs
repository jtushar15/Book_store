﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Diagnostics.Eventing.Reader;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Book_Store
{
    public partial class forget : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        public static int userid = 0;

        public forget()
        {
            InitializeComponent();
        }

       
       

        private void forget_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbBookStoreDataSet5.tblSignUp' table. You can move, or remove it, as needed.
            this.tblSignUpTableAdapter.Fill(this.dbBookStoreDataSet5.tblSignUp);

        }
        private bool valid()
        {
            if (txtoldpassword.Text == "")
            {
                MessageBox.Show("Please enter the old password");
                return false;
            }
            if (txtnewpassword.Text == "")
            {
                MessageBox.Show("Please enter the new password");
                return false;
            }
            if (txtconfirmpassword.Text == "")
            {
                MessageBox.Show("Please enter the conform password");
                return false;
            }
            if (txtnewpassword.Text != txtconfirmpassword.Text)
            {
                MessageBox.Show("New password and conform password does not match");
                return false;
            }
            return true;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                if (valid())
                {
                    if (cmbuserid.Text != "")
                    {
                        userid = Convert.ToInt32(cmbuserid.SelectedValue);
                        int user = Convert.ToInt32(cmbuserid.SelectedValue);
                        string pass = txtnewpassword.Text;
                        string cnfirmpass = txtconfirmpassword.Text;
                        SqlDataAdapter adptr = new SqlDataAdapter("select password from tblSignUp where userid='" + cmbuserid.SelectedValue + "'", con);
                        DataSet ds = new DataSet();
                        adptr.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            if (txtoldpassword.Text == ds.Tables[0].Rows[0][0].ToString())
                            {
                                string insertQuery = "update tblSignUp set password='"+@pass+"',confirm_password='"+ @cnfirmpass+ "' from tblSignUp where userid= '"+@user+"'";
                                SqlCommand insertcmd = new SqlCommand(insertQuery, con);
                                //insertcmd.Parameters.AddWithValue("@pass", pass);
                              // insertcmd.Parameters.AddWithValue("@cnfirmpass", cnfirmpass);
                                
                                insertcmd.Connection = con;
                                con.Open();
                                if (insertcmd.ExecuteNonQuery() > 0)
                                {
                                    MessageBox.Show("password change sucessfully");
                                    //txtclear();
                                }

                            }


                        }
                        else
                        {
                            MessageBox.Show("please enter the correct current Password");
                        }
                    }

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
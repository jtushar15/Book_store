﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class updatebook : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");


        public updatebook()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string updateQuery = "UPDATE BOOK SET bookTitle=@t, bookAuthor=@p, bookAvailability=@av, bookCategory=@c, WHERE bookId=@i";
            SqlCommand cmd = new SqlCommand(updateQuery, con);
            cmd.Parameters.AddWithValue("t", textBox3.Text);
            cmd.Parameters.AddWithValue("a", textBox4.Text);
            cmd.Parameters.AddWithValue("p", int.Parse(textBox5.Text));
            cmd.Parameters.AddWithValue("c", comboBox1.Text);
            cmd.Parameters.AddWithValue("av", comboBox2.Text);
            cmd.Parameters.AddWithValue("i", search_bar.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Successfully....!");
            con.Close();
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            search_bar.Text = "";
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "SELECT * FROM BOOK WHERE bookId =" + int.Parse(search_bar.Text);
            SqlCommand cmd = new SqlCommand(query, con);
            //mdr = cmd.ExecuteReader();
           // if (mdr.read())
            //{
           //     textBox2.Text = (mdr["bookId"].ToString());
           // }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files(*.jpg, *.jpeg, *.png, *.bmp) | *.jpg; *.jpeg; *.png, *.bmp";

            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                openFileDialog.Filter = openFileDialog.FileName; 
            }
        }

        private void updatebook_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Book_Store
{
    public partial class Add_Book_Dtl : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        OpenFileDialog pic = new OpenFileDialog();
        byte[] imgdata;
        byte[] imgdata1;
        public Add_Book_Dtl()
        {
            InitializeComponent();
        }
        private string selectedFilePath;

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == pic.ShowDialog())
            {
                pbphoto.ImageLocation = pic.FileName;
            }  
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void adddet_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            string insertBook = " INSERT INTO tblBookdtl(BookTitle, Authorname, bookprice, Category, Availability,Book_Image) VALUES(@t,@auth,@p,@a,@c,@Photo)";

            SqlCommand insertBookcmd = new SqlCommand(insertBook, con);
            //string ID = textBox1.Text;
            string title = textBox2.Text;
            string auther = textBox3.Text;
            string price = textBox4.Text;
            string category = comboBox1.SelectedItem.ToString();
            string availability = comboBox2.SelectedItem.ToString();


            if (pic.FileName != "")
            {
                imgdata = readfile(pic.FileName);

            }
            else
            {
                if (imgdata1 != null)
                {
                    insertBookcmd.Parameters.AddWithValue("@Photo", (object)imgdata1);
                }
                else
                {
                    imgdata = null;
                }
            }


            if (title == "" | price == "" | auther == "")
            {
                MessageBox.Show("Kindly Enter All Fields");
                return;
            }

           

            //insertBookcmd.Parameters.AddWithValue("@i", ID);
            insertBookcmd.Parameters.AddWithValue("@t", title);
            insertBookcmd.Parameters.AddWithValue("@auth", auther);
            insertBookcmd.Parameters.AddWithValue("@p", price);
            insertBookcmd.Parameters.AddWithValue("@a", category);
            insertBookcmd.Parameters.AddWithValue("@c", availability);
            insertBookcmd.Parameters.AddWithValue("@Photo", (object)imgdata);
            //  insertBookcmd.Parameters.AddWithValue("@book", button2);
           


            con.Open();
            insertBookcmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("New Book Details Added Succesfully :");

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";


        }


        byte[] readfile(string spatch)
        {
            byte[] data = null;
            FileInfo finfo = new FileInfo(spatch);
            long numbyte = finfo.Length;
            FileStream fstream = new FileStream(spatch, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fstream);
            data = br.ReadBytes((int)numbyte);
            return data;

        }

        private void Add_Book_Dtl_Load(object sender, EventArgs e)
        {
            //  this.tblSignUpTableAdaptetr.Fill(this.dbBookStoreDataSet3.tblSignUp);
        }

       

       
        private void button2_Click_2(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "All Files(*.*)|*.*"; // Set the file types you want to allow
            //openFileDialog.Filter = "All Files(*.*)|*.*"; // Set the file types you want to allow
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedFile = openFileDialog.FileName;
                MessageBox.Show(selectedFile);
                // Process the selected file (e.g., save it, display its content, etc.)

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Store
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            progressBar1.Visible = true;
            welcome w = new welcome();
            this.progressBar1.Value = this.progressBar1.Value + 2;
            if (this.progressBar1.Value == 10)
            {
                label3.Text = "Developed By : Tushar Jadhav, Naziya Shaikh & Vaibhavshri Ghodke..";
            }
            else if (this.progressBar1.Value == 20)
            {
                label3.Text = "Developed By : Tushar Jadhav...";
            }
            else if (this.progressBar1.Value == 30)
            {
                label3.Text = "Developed By : Naziya Shaikh..";
            }
            else if (this.progressBar1.Value == 40)
            {
                label3.Text = "Developed By : Vaibhavshri Ghodke..";
            }
            else if (this.progressBar1.Value == 50)
            {
                label3.Text = "Reading modules..";

            }
            else if (this.progressBar1.Value == 60)
            {
                label3.Text = "Turning on modules.";
            }
            else if (this.progressBar1.Value == 70)
            {
                label3.Text = "Starting modules..";
            }
            else if (this.progressBar1.Value == 80)
            {
                label3.Text = "Loading modules..";
            }
            else if (this.progressBar1.Value == 90)
            {
                label3.Text = "Done Loading modules..";
            }
            else if (this.progressBar1.Value == 100)
            {
                w.Show();

                timer1.Enabled = false;
                this.Hide();
                
            }
        
    }

        private void Splash_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

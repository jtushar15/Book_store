﻿namespace Book_Store
{
    partial class MDIParent1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details_byBookId = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details_byBookTitle = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details_byAuthorName = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details_byBookPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.View_Book_Details_byBookCategory = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(632, 22);
            this.statusStrip.TabIndex = 6;
            this.statusStrip.Text = "StatusStrip";
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.editMenu,
            this.viewMenu,
            this.logoutToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(632, 24);
            this.menuStrip.TabIndex = 4;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.toolStripSeparator5});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(82, 20);
            this.fileMenu.Text = "&User_Details";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(177, 6);
            // 
            // editMenu
            // 
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator6});
            this.editMenu.Name = "editMenu";
            this.editMenu.Size = new System.Drawing.Size(86, 20);
            this.editMenu.Text = "&Book_Details";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(177, 6);
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusBarToolStripMenuItem,
            this.bookToolStripMenuItem});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(59, 20);
            this.viewMenu.Text = "&Reports";
            // 
            // statusBarToolStripMenuItem
            // 
            this.statusBarToolStripMenuItem.Checked = true;
            this.statusBarToolStripMenuItem.CheckOnClick = true;
            this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
            this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.statusBarToolStripMenuItem.Text = "&User_Details";
            // 
            // bookToolStripMenuItem
            // 
            this.bookToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.View_Book_Details,
            this.View_Book_Details_byBookId,
            this.View_Book_Details_byBookTitle,
            this.View_Book_Details_byAuthorName,
            this.View_Book_Details_byBookPrice,
            this.View_Book_Details_byBookCategory});
            this.bookToolStripMenuItem.Name = "bookToolStripMenuItem";
            this.bookToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bookToolStripMenuItem.Text = "&Book_Details";
            // 
            // View_Book_Details
            // 
            this.View_Book_Details.Name = "View_Book_Details";
            this.View_Book_Details.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details.Text = "&View_Book_Details";
            // 
            // View_Book_Details_byBookId
            // 
            this.View_Book_Details_byBookId.Name = "View_Book_Details_byBookId";
            this.View_Book_Details_byBookId.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details_byBookId.Text = "&View_Book_Details_byBookId";
            // 
            // View_Book_Details_byBookTitle
            // 
            this.View_Book_Details_byBookTitle.Name = "View_Book_Details_byBookTitle";
            this.View_Book_Details_byBookTitle.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details_byBookTitle.Text = "&View_Book_Details_byBookTitle";
            // 
            // View_Book_Details_byAuthorName
            // 
            this.View_Book_Details_byAuthorName.Name = "View_Book_Details_byAuthorName";
            this.View_Book_Details_byAuthorName.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details_byAuthorName.Text = "&View_Book_Details_byAuthorName";
            // 
            // View_Book_Details_byBookPrice
            // 
            this.View_Book_Details_byBookPrice.Name = "View_Book_Details_byBookPrice";
            this.View_Book_Details_byBookPrice.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details_byBookPrice.Text = "&View_Book_Details_byBookPrice";
            // 
            // View_Book_Details_byBookCategory
            // 
            this.View_Book_Details_byBookCategory.Name = "View_Book_Details_byBookCategory";
            this.View_Book_Details_byBookCategory.Size = new System.Drawing.Size(264, 22);
            this.View_Book_Details_byBookCategory.Text = "&View_Book_Details_byBookCategory";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "&Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MDIParent1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.ControlBox = false;
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.Name = "MDIParent1";
            this.Text = "MDIParent1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details_byBookId;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details_byBookTitle;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details_byAuthorName;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details_byBookPrice;
        private System.Windows.Forms.ToolStripMenuItem View_Book_Details_byBookCategory;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
    }
}




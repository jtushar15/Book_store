﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Book_Store
{
    public partial class viewbook : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-51FRUQPU\\SQLEXPRESS;Initial Catalog=dbBookStore;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        SqlCommand cmd = new SqlCommand();
        public viewbook()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from tblBookdtl", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds, "fff");
            if (ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "fff";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select * from tblBookdtl where BookTitle='" + comboBox1.Text + "'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds, "fff");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGridView1.DataSource = ds;
                    dataGridView1.DataMember = "fff";

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string url = "https://epustakalay.com/book/182432-vedaa-by-kakasaheb-kalelkar-khalil-jibran-sripad-joshi/";
            string savePath = @"D:\Book_Store\book\cp-lab-manual.pdf";
            WebClient client = new WebClient();
            client.DownloadFile(url, savePath);
            Console.ReadLine();
            MessageBox.Show("Book Download Sucessfully");


        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("delete from tblBookdtl where bookid=" + comboBox1.SelectedValue + "", con);
            SqlCommand cmd3 = new SqlCommand("Delete From Table1 Where id+@id", con);
            cmd3.Parameters.AddWithValue("id", comboBox1.Text);

                
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                SqlDataAdapter adptr3 = new SqlDataAdapter("select * from tblBookdtl", con);
                DataSet ds3 = new DataSet();
                adptr3.Fill(ds3);
                if (ds3.Tables[0].Rows.Count > 0)
                {
                        MessageBox.Show("delete suessfully");
                }
                else
                {
                    MessageBox.Show("Please Select Record to Delete");

                }
            }
            con.Close();
        }

        private void viewbook_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbBookStoreDataSet4.tblBookdtl' table. You can move, or remove it, as needed.
            this.tblBookdtlTableAdapter.Fill(this.dbBookStoreDataSet4.tblBookdtl);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

